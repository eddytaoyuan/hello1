#!/bin/bash

echo "this is a test from yuan tao" >&2
